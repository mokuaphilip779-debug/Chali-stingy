 const fs = require('fs')
global.owner = ['254115417774']
global.status = false
global.gambar = ""
global.location = "Kenya, Sosiot"
global.footer = "PHILO BOT"
global.link = "https://whatsapp.com/channel/0029Vb6UbVy4dTnT2N7T6E2z"
global.autobio = false
global.botName = "PHILO BOT"
global.version = "1.0.0"
global.themeemoji = "😎"
global.thumbnail = ""
global.packname = "PHILO BOT"
global.author = "Philip 254115417774"
global.creator = "254115417774@s.whatsapp.net"
global.database = "*Bot Active - Created by Philip*"

global.autoviewstatus = false

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})